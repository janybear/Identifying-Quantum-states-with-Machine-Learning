import numpy as np

datapoints=1000000
#Create a list to fill with generated prob amplitudes
p=[]
f=[]


for i in range(datapoints):
    u=[]
    for i in range(4):
        real=np.random.uniform(-0.9999, 0.9999)
        comp=np.random.uniform(-0.9999, 0.9999)   
        u.append(real)
        u.append(comp)
    f_abs_squared= np.array([u[0]**2+u[1]**2 , u[2]**2+u[3]**2,
                             u[4]**2+u[5]**2, u[6]**2+u[7]**2])
    #multiplying by the quantum amplitude normalization factor
    y=u/np.sqrt(np.sum(f_abs_squared))
    p.append(y)
    
    f1= np.array([ y[0]+y[1]*1j , y[2]+y[3]*1j, 
                  y[4]+y[5]*1j, y[6]+y[7]*1j ])
    f.append(f1) 

fourvec=np.array(f)
prob_amps=np.array(p)



# print(prob_amps[0])
# check = [ ((prob_amps[0][0])**2 + (prob_amps[0][1])**2)  + ((prob_amps[0][2])**2 + (prob_amps[0][3])**2) +  ((prob_amps[0][4])**2 + (prob_amps[0][5])**2) + ((prob_amps[0][6])**2 + (prob_amps[0][7])**2)]
# print("check=", check)
# print(np.shape(dist2))
# pplot doesnt work for hilbert space, does work to check initial random dist.
# note:prob amp can have negativity
# but prob will not.

# dist1=[]
#     dist1.append(u)
# dist2_=np.array(dist1)

# try histogram to check if gen values span the hilbert/poincare sphere space correctly?


# plt.figure(figsize=(10, 5))
# for j in range(dp):
#     for i in range(8):
#         plt.plot(j, dist2[j][i], marker='o', markersize=2)
# plt.xlabel('Datapoints')
# plt.ylabel('Random Number Generated')
# yticks = np.arange(-1.00, 1.25, 0.25)
# #plt.title('Data Distribution of Generated Probability Amplitudes')
# plt.legend()
# plt.grid(True)
# plt.show()


# plt.figure(figsize=(10, 5))
# for j in range(dp):
#     for i in range(8):
#         plt.plot(j, prob_amps[j][i], marker='o', markersize=2)
# plt.xlabel('Datapoints')
# plt.ylabel('Probability Amplitude Value')
# plt.yticks(np.arange(-1.00, 1.25, 0.25))
# #plt.title('Data Distribution of Generated Probability Amplitudes')
# plt.legend()
# plt.grid(True)
# plt.show()


import pickle

#saving file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "prob_amps.pickle"

# Combine the directory and filename to get the full path
full_path = directory + filename

# Pickle the array and save it to the specified file
with open(full_path, 'wb') as file:
    pickle.dump(prob_amps, file)
    
    
    
#saving file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "fourvec.pickle"
# Combine the directory and filename to get the full path
full_path = directory + filename

# Pickle the array and save it to the specified file
with open(full_path, 'wb') as file:
    pickle.dump(fourvec, file)
