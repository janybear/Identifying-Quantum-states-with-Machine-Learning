# -*- coding: utf-8 -*-
"""
Created on Sat Sep 30 19:10:05 2023

@author: USER
"""

#tensorflow method
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from keras.layers import Dense, LeakyReLU
import matplotlib.pyplot as plt
import pickle
import numpy as np


dp= 5000000
input_shape = 36
output_shape = 8

# Load the pickled array inputs
directory = "C:\\Users\\USER\\Desktop\\REPORT STUFF\\model final for 23 october submission\\" #"C:\\Users\\USER\\Desktop\\model\\complete data packs\\data1\\" 
filename = "Meas_negative.pickle"
# Combine the directory and filename to get the full path
full_path = directory + filename
with open(full_path, 'rb') as file:
    Meas = pickle.load(file)

#load in outputs
directory = "C:\\Users\\USER\\Desktop\\REPORT STUFF\\model final for 23 october submission\\"
filename = "prob_amps_negative.pickle"
# Combine the directory and filename to get the full path
full_path = directory + filename
#loading in pickle file
with open(full_path, 'rb') as file:
    prob_amps = pickle.load(file)
    
#re-normalizing data:
#RN_prob_amps = ( (prob_amps + np.ones(8))/2 )*0.95


# prob_amps1 = np.load("C:\\Users\\USER\\Desktop\\model\\complete data packs\\data1\\prob_amps1.npy")

dp= 5000000
input_shape = 36
output_shape = 8

# Define the dataset (input matrices and corresponding output lists)
input_data = Meas
output_data = prob_amps

# Create a custom callback to store epoch history
class CustomHistoryCallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        if 'epoch_history' not in vars(self):
            self.epoch_history = []

        self.epoch_history.append({
            'epoch': epoch + 1,
            'loss': logs['loss'],
            'val_loss': logs['val_loss']
            # Add other metrics as needed
        })

# Split the dataset into training and testing sets
split_ratio = 0.7
split_index = int(dp * split_ratio)

train_input = input_data[:split_index]
train_output = output_data[:split_index]
test_input = input_data[split_index:]
test_output = output_data[split_index:]


# Define a neural network model
model = keras.Sequential([
    layers.Input(shape=input_shape),
    layers.Flatten(),
    layers.Dense(512, activation='ReLU'),
    layers.Dense(128, activation='ReLU'),
    layers.Dense(64, activation='ReLU'),
    layers.Dense(32, activation='LeakyReLU'),
    layers.Dense(8, activation='LeakyReLU')  # Output layer with 4 neurons for regression
])

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mse']) #adam seems to still be the best option


# Train the model
batch_size = 10000
epochs = 100

#(alpha=0.1)
# Create an instance of the custom callback
custom_callback = CustomHistoryCallback()

history=model.fit(train_input, train_output, batch_size=batch_size, epochs=epochs, validation_data=(test_input, test_output), callbacks=[custom_callback])

# Access the epoch history as a list of dictionaries
epoch_history = custom_callback.epoch_history

# Convert the epoch history to a NumPy array
epoch_history_array = np.array(epoch_history)

# Evaluate the model on test data
test_loss, test_mse = model.evaluate(test_input, test_output)
print(f"Test Loss: {test_loss}, Test MSE: {test_mse}")





import os
os.chdir("C:\\Users\\USER\\Desktop\\REPORT STUFF")

from tensorflow.keras.models import model_from_json

# Save model architecture as JSON
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)
#save weights
model.save('model_architecture.json')
model.save_weights('model_weights.h5')