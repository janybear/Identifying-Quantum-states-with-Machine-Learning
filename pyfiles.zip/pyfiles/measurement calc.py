# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 13:49:28 2023

@author: USER
"""
import numpy as np
import pickle
#loading file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL FINAL\\"
filename = "density_matrices.pickle"

# Combine the directory and filename to get the full path
full_path = directory + filename

with open(full_path, 'rb') as file:
    density_matrices = pickle.load(file)

import math

#the 6 basis states
R = np.array([[1],[0]], ndmin=2)
L = np.array([[0],[1]], ndmin=2)
H = 1/math.sqrt(2)*np.array([[1],[1j]], ndmin=2)
V = -1j*1/math.sqrt(2)*np.array([[1],[-1j]], ndmin=2)
D = 1/math.sqrt(2)*np.array([[1],[1]], ndmin=2)
A = 1j*1/math.sqrt(2)*np.array([[1],[-1]], ndmin=2)

list_1= [H,V,D,A,R,L]


empty2=[]
for i in list_1:
  empty1=[]
  for j in list_1:
    m= np.kron(i,j) #tensor product of the 2 photons polarizations
    proj=np.outer(m, np.conj(m))
    pro=proj.flatten()
    empty2.append(pro)
projectors=np.array(empty2)
#projectors=np.load("C://Users//USER//Desktop//REPORT STUFF//model final for 23 october submission//projectors.npy")

#measurement=expectation value matrix/dataframe , will need to get 36 measurements for each of the 20 states - array of 20 arrays that contain 6x6 matrices (36 elements)
Measurement=[]
for dm in density_matrices:
  list1=[]
  for j in projectors:
    expectation_val=np.matmul(dm, j)
    expectationval_noise= (expectation_val.real)*(np.random.uniform(1,1.15))
    list1.append(expectationval_noise)
  list2=np.array(list1)*(np.random.uniform(1,1.05))
  Measurement.append(list1)
Meas=np.array(Measurement)
#print("Meas=",Meas_[1], np.shape(Meas_))

import pickle
#saving file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL FINAL\\"
filename = "Meas.pickle"

# Combine the directory and filename to get the full path
full_path = directory + filename

# Pickle the array and save it to the specified file
with open(full_path, 'wb') as file:
    pickle.dump(Meas, file)
    
# Load the pickled array from the file
#with open(full_path, 'rb') as file:
   # loaded_Meas1 = pickle.load(file)