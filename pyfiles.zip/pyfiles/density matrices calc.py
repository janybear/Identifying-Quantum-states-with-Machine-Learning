# -*- coding: utf-8 -*-
"""
Created on Sun Oct  1 02:39:17 2023

@author: USER
"""
import numpy as np 
import pickle
#loading file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "fourvec.pickle"

# Combine the directory and filename to get the full path
full_path = directory + filename

with open(full_path, 'rb') as file:
    fourvec = pickle.load(file)
    
  
# complex density matrix
density_matrices1=[]
for i in fourvec:
  Psi=i
  p_12=np.outer(Psi, np.conj(Psi))
  p12=p_12.flatten()
  density_matrices1.append(p12)
density_matrices=np.array(density_matrices1)



print("dm=", density_matrices[0])

import pickle
#saving file - pickling
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "density_matrices.pickle"

# Combine the directory and filename to get the full path
full_path = directory + filename

# Pickle the array and save it to the specified file
with open(full_path, 'wb') as file:
    pickle.dump(density_matrices, file)

    
