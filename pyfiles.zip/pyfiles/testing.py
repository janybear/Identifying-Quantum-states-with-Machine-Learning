# -*- coding: utf-8 -*-
"""
Created on Sat Sep 30 23:23:14 2023

@author: USER
"""
import numpy as np
import math

projectors = np.load("C:\\Users\\USER\\Desktop\\Project\\model\\normal\\data\\projectors.npy")

#import model
import os
os.chdir("C:\\Users\\USER\\Desktop\\Project\\model\\normal")

from tensorflow.keras.models import model_from_json, load_model

# Load the model architecture from the JSON file.
with open('model.json', 'r') as json_file:
    loaded_model_json = json_file.read()
    loaded_model = model_from_json(loaded_model_json)

# Load the model weights.
loaded_model.load_weights('model_weights.h5')

#A TEST ON UNIQUELY SIMULATED/GENERATED DATA

num = 50

#Complex prob amps
lst=[]
tst=[]                                                              #Create a list to fill with generated prob amplitudes
for i in range(num):
  u=[]
  for i in range(4):
    real=np.random.uniform(0, 1)
    comp=np.random.uniform(0, 1)*1j
    u.append(real)
    u.append(comp)
  values=np.array([(u[0]+u[1]), (u[2]+u[3]), (u[4]+u[5]), (u[6]+u[7])])
  div=np.sum(values)
  norm=values/div
  u1=np.sqrt(norm)
  tst.append(u1)
  u2=np.array([u1[0].real, u1[0].imag, u1[1].real, u1[1].imag,  u1[2].real, u1[2].imag, u1[3].real, u1[3].imag]) #seperating into 8 seperate values but this gets rid of the imag number - j !!!
  lst.append(u2)
fourvec = np.array(tst) #this is the prob amps as a 4x1
prob_amps1=np.array(lst) #this is the prob amps as an 8x1


#to check that the sum of the squares of the prob amps are 1.
s=0
for e in fourvec[0]:
  s += e**2
print("to check that the sum of the squares of the prob amps are 1:",s) #works!    # could use math.isclose(); this function aims to allow you to ‘ignore’ the small differences between floating point values, the imaginary part here should be 0


# complex density matrix
density_matrices=[]
for i in range(num):
  Psi=fourvec[i]
  p_12=np.outer(Psi, np.conj(Psi))
  p12=p_12.flatten()
  density_matrices.append(p12)

#to seperate into real and imag: #good for plotting!
real=density_matrices[0].real
imag=density_matrices[0].imag
#print(real, imag)

#measurement=expectation value matrix/dataframe , will need to get 36 measurements for each of the 20 states - array of 20 arrays that contain 6x6 matrices (36 elements)
Measurements=[]
for dm in density_matrices:
  list1=[]
  for j in projectors:
    expectation_val=np.matmul(dm, j)
    expectationval_noise= (expectation_val.real)*(np.random.uniform(1,1.15))
    list1.append(expectationval_noise)
  Measurements.append(list1)
Meas1=np.array(Measurements)

# Make predictions for the new input data
predictions = loaded_model.predict(Meas1)
predictions=np.array(predictions)
testers=np.reshape(prob_amps1,(50,8))

j=0
errordot=[]
for i in range(num):
  error=np.dot(predictions[j], testers[j])
  errordot.append(error)
  j=j+1
errors=np.array(errordot)-np.ones(num)
print(errors)

s=0
for e in errors:
  s += e**2

toplot=(errors/1)*100

average_error= sum((abs(errors)/1)*100)/num
print("average error=", average_error, "%")

import matplotlib.pyplot as plt

plt.figure(figsize=(10, 5))
plt.plot(range(num), toplot, label='dot(testers, predictions)', marker='o')
plt.xlabel('datapoint')
plt.ylabel('error (%)')
plt.title('dot product average error = , (for *** dp noisy data)')
plt.legend()
plt.grid(True)
plt.show()
