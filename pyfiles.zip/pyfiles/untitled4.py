# -*- coding: utf-8 -*-
"""
Created on Tue Oct 24 21:59:19 2023

@author: USER
"""

#FOR TRAINING THE DATA

#tensorflow method
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt
import pickle
import numpy as np

#load in outputs
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "prob_amps.pickle"
# Combine the directory and filename to get the full path
full_path = directory + filename
#loading in pickle file
with open(full_path, 'rb') as file:
    prob_amps = pickle.load(file)


# Load the pickled array inputs
directory = "C:\\Users\\USER\\Desktop\\MODEL FINAL\\"
filename = "Meas.pickle"
# Combine the directory and filename to get the full path
full_path = directory + filename
with open(full_path, 'rb') as file:
    Meas = pickle.load(file)


dp= 1000000
input_shape = (36, 1)
output_shape = 8

# Define the dataset (input matrices and corresponding output lists)
input_data = Meas
output_data = prob_amps

# Create a custom callback to store epoch history
class CustomHistoryCallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        if 'epoch_history' not in vars(self):
            self.epoch_history = []

        self.epoch_history.append({
            'epoch': epoch + 1,
            'loss': logs['loss'],
            'val_loss': logs['val_loss']
            # Add other metrics as needed
        })

# Split the dataset into training and testing sets
split_ratio = 0.7
split_index = int(dp * split_ratio)

train_input = input_data[:split_index]
train_output = output_data[:split_index]
test_input = input_data[split_index:]
test_output = output_data[split_index:]

# Define a neural network model
model = keras.Sequential([
    layers.Input(shape=input_shape),
    layers.Flatten(),
    
    layers.Dense(64, activation='leakyrelu'),
    layers.Dense(16, activation='LeakyReLU'),
    layers.Dense(8, activation='LeakyReLU')  # Output layer with 4 neurons for regression
])

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mse']) #adagrad adadelta


# Train the model
batch_size = 30 #dec
epochs = 20 #inc


# Create an instance of the custom callback
custom_callback = CustomHistoryCallback()

history=model.fit(train_input, train_output, batch_size=batch_size, epochs=epochs, validation_data=(test_input, test_output), callbacks=[custom_callback])

# Access the epoch history as a list of dictionaries
epoch_history = custom_callback.epoch_history

# Convert the epoch history to a NumPy array
epoch_history_array = np.array(epoch_history)

# Evaluate the model on test data
test_loss, test_mse = model.evaluate(test_input, test_output)
print(f"Test Loss: {test_loss}, Test MSE: {test_mse}")